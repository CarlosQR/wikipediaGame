
var timesPlayed= localStorage.getItem("timesPlayed")

var i = 0
var span=""
var start=""
var destination=""
var time= 0
console.log("WOrks")

function convertSecondsToMinutes(seconds) {
  var minutes = Math.floor(seconds / 60);
  var remainingSeconds = seconds % 60;

  // If the number of remaining seconds is less than 10, we'll add a leading zero
  if (remainingSeconds < 10) {
    remainingSeconds = "0" + remainingSeconds;
  }

  return minutes + ":" + remainingSeconds;
}


for(i=1;i<=timesPlayed;i++){
	console.log(i)
	start=(localStorage.getItem("Round"+i).split(","))[0]
	destination=(localStorage.getItem("Round"+i).split(","))[1]
	time=convertSecondsToMinutes((localStorage.getItem("Round"+i).split(","))[2])
	
	
var span= span + "Round"+i+": "+ "Started at "+start+" got to "+ destination+" in "+ time + "minutes"+"<br><br>"

}
console.log(span)

document.getElementById("statsList").innerHTML=span