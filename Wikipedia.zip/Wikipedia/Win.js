chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
  chrome.tabs.sendMessage(tabs[0].id, {message: "Game Ended"}, function(response) {
    console.log(response.farewell);
  });
});
function convertSecondsToMinutes(seconds) {
  var minutes = Math.floor(seconds / 60);
  var remainingSeconds = seconds % 60;

  // If the number of remaining seconds is less than 10, we'll add a leading zero
  if (remainingSeconds < 10) {
    remainingSeconds = "0" + remainingSeconds;
  }

  return minutes + ":" + remainingSeconds;
}



if(localStorage.getItem("timesPlayed")==null){
	
	localStorage.setItem("timesPlayed",1)
	timesPlayed=parseInt(localStorage.getItem("timesPlayed"))
	console.log("if")
	
}else{
	console.log("else")
	var timesPlayed = parseInt(localStorage.getItem("timesPlayed"))
	
	localStorage.setItem("timesPlayed",timesPlayed+1)
}


timesPlayed = parseInt(localStorage.getItem("timesPlayed"))


 var destination = localStorage.getItem("Destination")
 
 var start = localStorage.getItem("Start")

var time = localStorage.getItem("timer")

document.getElementById("Destination").innerHTML="You ended at : "+destination

document.getElementById("Start").innerHTML="You started at: "+ start

document.getElementById("Time").innerHTML="Your time was:"+convertSecondsToMinutes(time)+"minutes"


localStorage.setItem("Round"+ String(timesPlayed),[start,destination,time])