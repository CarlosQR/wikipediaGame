
			/*	
//Chat GP
var timerInterval= setInterval(startTimer,1000)
function startTimer() {
//timer=localStorage.getItem("timer")
    timer++;
   $("#timer").html(String((Math.floor(timer / 60) + ":" + ("0" + (timer % 60)).slice(-2))));

					 
*/
console.log("Bet")

let timer = 0;
//Chat GP
var timerInterval= setInterval(startTimer,1000)
function startTimer() {
timer=localStorage.getItem("timer")
    timer++;
  // $("#timer").html(String((Math.floor(timer / 60) + ":" + ("0" + (timer % 60)).slice(-2))));

	
	
chrome.runtime.sendMessage({ timer: timer}, function(response) {
  console.log(response.farewell);
});
          	localStorage.setItem("timer",timer)
	console.log(timer)
	
	

}


;

startTimer()


chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
	    sendResponse({farewell: "goodbye"});
console.log(request.message);
	  
if(request.message=="Game Ended"){
	
	clearInterval(timerInterval)
	
		localStorage.setItem("timer",0)
	
}
  }
);
  
  // Send a response back to the popup




console.log(timer)
/*
function(request, sender, sendResponse) {
    sendResponse({respond: 
				 "mmmmm"

				 
				 
				 })};*/