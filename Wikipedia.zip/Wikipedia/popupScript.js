
//If New Game Button is clicked this fuction runs
var destination=""
var RandomString = ""
var options=[]
var i =0
var DisplayString=""


if(localStorage.getItem("GameStatus")=="midGame"){
	
	
	window.location.href="GamePage.html"
}

$("#Stats").click(function(){
	

	window.location.href="Stats.html"
})
function GetPages(){
	
	
	
	
	

	
$.ajax({
  url: "https://en.wikipedia.org/w/api.php?origin=*&format=json&action=query&generator=random&grnnamespace=0&prop=revisions|images&rvprop=content",
  success: function(data) {
  var  start = (getTitleStart(data));
	 
  },
  error: function(xhr, error) {
    console.log(xhr);
    console.log(error);
  }
});
/*
function getTitle(data) {
  let pages = data.query.pages;
  let firstKey = Object.keys(pages)[0];
  return pages[firstKey].title;
}

*/
	
$.ajax({
  url: "https://en.wikipedia.org/w/api.php?origin=*&format=json&action=query&generator=random&grnnamespace=0&prop=revisions|images&rvprop=content",
  success: function(data) {
	  
	  
	
  // $("#wikiResult").html("Start at "+getTitle(data)+ " go to "+ destination);
	 getTitle(data)
  },
  error: function(xhr, error) {
    console.log(xhr);
    console.log(error);
  }
});

function getTitle(data) {
	
	let RandomString = JSON.stringify(data)

	
  let pages = data.query.pages;
	//console.log(pages)
  let firstKey = Object.keys(pages)[0];
	console.log(firstKey)
		//console.log(RandomString)
	console.log(RandomString.includes("Living people"))
if(RandomString.includes("Living people")){
	
	options.push(pages[firstKey].title)
}
	console.log(pages[firstKey].title)
  return pages[firstKey].title;
}
	
	function getTitleStart(data) {
	
	let RandomString = JSON.stringify(data)

	
  let pages = data.query.pages;
	//console.log(pages)
  let firstKey = Object.keys(pages)[0];
	console.log(firstKey)
		//console.log(RandomString)
	console.log(RandomString.includes("Living people"))

  return pages[firstKey].title;
}
	
	}

$("#Start").click(function(){

window.location.href="ChoseCategory.html"	
	
for(i=0;i<10;i++){
		
	
GetPages()
	
	
console.log(options)

	
}
	
	setTimeout(function Filter(){
			  console.log(options.length)
console.log(options.length!==0)
		
			 // $("#wikiResult").html("Start at "++ " go to "+ options[0])
				localStorage.setItem("lastname", "Smith");
		window.location.href="ChoseCategory.html"
			  options=options.slice(options.length)
		
			  }, 5000)

	
})




/*
var i = 0
var options =[]
console.log("end")




 for (let i = 0; i <= 20; i++){
$.ajax({
  url: "https://en.wikipedia.org/w/api.php?origin=*&format=json&action=query&generator=random&grnnamespace=0&prop=revisions|images&rvprop=content",
  success: function(data) {
	  
	 
	 var Title=getTitle(data)
	  
  // $("#wikiResult").html("Start at "+getTitle(data)+ " go to "+ destination);
  },
  error: function(xhr, error) {
    console.log(xhr);
    console.log(error);
  }
});	
	

var RandomString = ""
function getTitle(data) {

	let RandomString = JSON.stringify(data)
	console.log(RandomString)
	
	
	
  let pages = data.query.pages;
	console.log(pages)
  let firstKey = Object.keys(pages)[0];
	console.log(firstKey)
	console.log(i)
	console.log(RandomString.includes("Living people"))
	
		
		options.push(RandomString)	
		
		return pages[firstKey].title
		

		
	
  ;


}
	 
	
	
	
	
}


for(pages in options){
	
	if(options[pages].includes("Living people")){
		
		console.log("Chosen:"+ pages)
		break
	}
		
}
*/
//let RandomString = JSON.stringify(data)

//RandomString.includes("Living people")
